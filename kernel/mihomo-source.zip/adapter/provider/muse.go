package provider

import (
	"encoding/json"
	"errors"
	"golang.org/x/net/http/httpguts"
	"io"
	"maps"
	"net"
	"net/url"
	"reflect"
	"strings"

	"github.com/metacubex/mihomo/adapter"
	"github.com/metacubex/mihomo/adapter/outbound"
)

type museRow struct {
	Label  string         `json:"label"`
	Kind   string         `json:"kind"`
	Reason string         `json:"reason,omitempty"`
	Node   map[string]any `json:"node,omitempty"`
}

var museRows *[]museRow
var errMuse = errors.New("invalid provider snapshot")

func MuseAccountPolicy() adapter.ProxyOption { return adapter.WithProxyDecoder(&museRow{}) }

func MuseRead(input io.Reader, output io.Writer) error {
	var source string
	if json.NewDecoder(io.LimitReader(input, 16384)).Decode(&source) != nil {
		return errMuse
	}
	endpoint, err := url.Parse(source)
	if err != nil || endpoint.Hostname() == "" || endpoint.User != nil || endpoint.Fragment != "" || !(endpoint.Scheme == "https" || endpoint.Scheme == "http" && net.ParseIP(endpoint.Hostname()).IsLoopback()) {
		return errMuse
	}
	rows := []museRow{}
	museRows = &rows
	feed, err := ParseProxyProvider("muse", map[string]any{"type": "http", "url": source, "size-limit": (1 << 20) + 1, "header": map[string][]string{"User-Agent": {"Mihomo/v1.19.34-Muse-0.1.11"}}, "override": map[string]any{"skip-cert-verify": false}}, nil)
	if err != nil {
		return err
	}
	defer feed.(*ProxySetProvider).Close()
	if err = feed.Update(); err != nil {
		return err
	}
	proxies := feed.Proxies()
	count := 0
	for _, row := range rows {
		if row.Node != nil {
			if row.Reason != "" || count >= len(proxies) || proxies[count].Name() != row.Node["name"] {
				return errMuse
			}
			row.Node["name"] = "account"
			count++
		}
	}
	if len(rows) == 0 || count != len(proxies) {
		return errMuse
	}
	return json.NewEncoder(output).Encode(rows)
}

func (row *museRow) reject(category string) error {
	row.Reason = category
	return errMuse
}

func (row *museRow) unused(value any) error {
	switch v := value.(type) {
	case nil:
		return nil
	case string:
		if v == "" {
			return nil
		}
	case bool:
		if !v {
			return nil
		}
	case map[string]any:
		if len(v) == 0 {
			return nil
		}
	case []any:
		if len(v) == 0 {
			return nil
		}
	default:
		if reflect.ValueOf(v).IsZero() {
			return nil
		}
	}
	return row.reject("unknown_option")
}

func (row *museRow) Decode(mapping map[string]any, dst any) error {
	decoder := adapter.NewProxyDecoder(row.unused)
	if _, ok := dst.(*outbound.SingMuxOption); ok {
		return decoder.Decode(mapping, dst)
	}
	// ParseProxy selected an actual adapter. Never echo an unrecognized type.
	row.Kind, _ = mapping["type"].(string)
	switch row.Kind {
	case "direct", "rematch", "reject", "dns":
		return row.reject("not_remote")
	case "wireguard", "openvpn", "tailscale", "zerotier", "easytier":
		return row.reject("tunnel")
	case "masque", "shadowquic", "ssh":
		return row.reject("trust_model")
	}
	fields := maps.Clone(mapping)
	delete(fields, "type")
	if mux, exists := fields["smux"]; exists {
		if _, ok := mux.(map[string]any); !ok && mux != nil {
			return row.reject("native_parse")
		}
		delete(fields, "smux")
	}
	if err := decoder.Decode(fields, dst); err != nil {
		return err
	}
	option := reflect.ValueOf(dst).Elem()
	active := func(names ...string) bool {
		for _, name := range names {
			if field := option.FieldByName(name); field.IsValid() && !field.IsZero() {
				return true
			}
		}
		return false
	}
	if active("DialerProxy", "Interface", "RoutingMark", "Ports", "PortRange", "Ip") {
		return row.reject("other_egress")
	}
	if active("Certificate", "PrivateKey") {
		return row.reject("local_resource")
	}
	if active("SkipCertVerify", "DisableSni", "NameCertVerify", "Fingerprint", "ShadowTLSOpts", "RestlsOpts", "JLSOpts") {
		return row.reject("trust_model")
	}
	if field := option.FieldByName("RealityOpts"); field.IsValid() && field.FieldByName("PublicKey").String() != "" {
		return row.reject("trust_model")
	}
	if field := option.FieldByName("RealmOpts"); field.IsValid() && field.FieldByName("Enable").Bool() {
		return row.reject("other_egress")
	}
	if field := option.FieldByName("ECHOpts"); field.IsValid() && field.FieldByName("Enable").Bool() && field.FieldByName("Config").String() == "" {
		return row.reject("other_egress")
	}
	if active("MinIdleSession", "HealthCheck") {
		return row.reject("active_probe")
	}
	switch parsed := dst.(type) {
	case *outbound.HttpOption:
		for header, value := range parsed.Headers {
			if !httpguts.ValidHeaderFieldName(header) || !httpguts.ValidHeaderFieldValue(value) {
				return row.reject("native_parse")
			}
		}
	case *outbound.ShadowSocksOption:
		switch parsed.Plugin {
		case "":
			if len(parsed.PluginOpts) > 0 {
				return row.reject("unknown_option")
			}
		case "obfs":
			if err := outbound.MuseCheckSimpleObfs(parsed.PluginOpts, row.unused); err != nil {
				return err
			}
		default:
			return row.reject("transport")
		}
	case *outbound.SnellOption:
		if len(parsed.ObfsOpts) > 0 {
			return row.reject("transport")
		}
	case *outbound.HysteriaOption:
		if (parsed.Protocol != "" && parsed.Protocol != "udp") || (parsed.ObfsProtocol != "" && parsed.ObfsProtocol != "udp") {
			return row.reject("transport")
		}
	case *outbound.VmessOption:
		if parsed.TLSMirrorOpts.PrimaryKey != "" || parsed.Network == "mekya" {
			return row.reject("transport")
		}
	case *outbound.VlessOption:
		if parsed.Network == "xhttp" && parsed.XHTTPOpts.DownloadSettings != nil {
			return row.reject("other_egress")
		}
	case *outbound.SudokuOption:
		maskTLS := parsed.HTTPMaskTLS && (parsed.HTTPMask == nil || *parsed.HTTPMask)
		if parsed.HTTPMaskOptions != nil {
			maskTLS = parsed.HTTPMaskOptions.TLS && !parsed.HTTPMaskOptions.Disable
		}
		if maskTLS {
			return row.reject("transport")
		}
	}
	host, port := option.FieldByName("Server"), option.FieldByName("Port")
	if !host.IsValid() || !port.IsValid() || host.Kind() != reflect.String || port.Kind() != reflect.Int {
		return row.reject("tunnel")
	}
	if host.String() == "" || strings.ContainsAny(host.String(), "/\\@?#\x00 \r\n\t") || port.Int() < 1 || port.Int() > 65535 {
		return row.reject("native_parse")
	}
	if mapping["dialer-proxy"] == "" {
		delete(mapping, "dialer-proxy")
	}
	if _, ok := mapping["port"]; ok {
		mapping["port"] = int(port.Int())
	}
	return nil
}
